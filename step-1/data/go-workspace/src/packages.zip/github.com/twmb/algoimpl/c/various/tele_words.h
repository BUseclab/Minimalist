#ifndef TELE_WORDS_TWMB
#define TELE_WORDS_TWMB

// Assuming numbers contains only ascii digits,
// this function cycles through and prints all
// variations of letters that the numbers could
// be. 0=Y, 1=Z, 2=A,B,C, 3=etc.
void phone_number_letters(char *numbers, int len);

#endif
