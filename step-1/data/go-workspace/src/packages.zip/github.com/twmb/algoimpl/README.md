# Algoimpl

A collection of various algorithms in various languages. I have tried
to organize them into appropriate directories in case anybody wants to
import a package in to their library.

My go [graph](http://godoc.org/github.com/twmb/algoimpl/go/graph) package
is well built. Use it. Give me suggestions.
