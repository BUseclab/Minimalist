<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 *
 * @package PhpMyAdmin
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/**
 * returns code for selecting databases
 *
 * @return String HTML code
 */
function PMA_replication_db_multibox()
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_replication_db_multibox") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php at line 18")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_replication_db_multibox:18@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php');
    die();
}
/**
 * prints out code for changing master
 *
 * @param String $submitname - submit button name
 *
 * @return void
 */
function PMA_replication_gui_changemaster($submitname)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_replication_gui_changemaster") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php at line 51")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_replication_gui_changemaster:51@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php');
    die();
}
/**
 * This function prints out table with replication status.
 *
 * @param string  $type   either master or slave
 * @param boolean $hidden if true, then default style is set to hidden, default value false
 * @param boolen  $title  if true, then title is displayed, default true
 *
 * @return void
 */
function PMA_replication_print_status_table($type, $hidden = false, $title = true)
{
    global ${"{$type}_variables"};
    global ${"{$type}_variables_alerts"};
    global ${"{$type}_variables_oks"};
    global ${"server_{$type}_replication"};
    global ${"strReplicationStatus_{$type}"};
    // TODO check the Masters server id?
    // seems to default to '1' when queried via SHOW VARIABLES , but resulted in error on the master when slave connects
    // [ERROR] Error reading packet from server: Misconfigured master - server id was not set ( server_errno=1236)
    // [ERROR] Got fatal error 1236: 'Misconfigured master - server id was not set' from master when reading data from binary log
    //
    //$server_id = PMA_DBI_fetch_value("SHOW VARIABLES LIKE 'server_id'", 0, 1);
    echo '<div id="replication_' . $type . '_section" style="' . ($hidden ? 'display: none;' : '') . '"> ';
    if ($title) {
        if ($type == 'master') {
            echo '<h4><a name="replication_' . $type . '"></a>' . __('Master status') . '</h4>';
        } else {
            echo '<h4><a name="replication_' . $type . '"></a>' . __('Slave status') . '</h4>';
        }
    } else {
        echo '<br />';
    }
    echo '   <table id="server' . $type . 'replicationsummary" class="data"> ';
    echo '   <thead>';
    echo '    <tr>';
    echo '     <th>' . __('Variable') . '</th>';
    echo '        <th>' . __('Value') . '</th>';
    echo '    </tr>';
    echo '   </thead>';
    echo '   <tbody>';
    $odd_row = true;
    foreach (${"{$type}_variables"} as $variable) {
        echo '   <tr class="' . ($odd_row ? 'odd' : 'even') . '">';
        echo '     <td class="name">';
        echo $variable;
        echo '     </td>';
        echo '     <td class="value">';
        // TODO change to regexp or something, to allow for negative match
        if (isset(${"{$type}_variables_alerts"}[$variable]) && ${"{$type}_variables_alerts"}[$variable] == ${"server_{$type}_replication"}[0][$variable]) {
            echo '<span class="attention">';
        } elseif (isset(${"{$type}_variables_oks"}[$variable]) && ${"{$type}_variables_oks"}[$variable] == ${"server_{$type}_replication"}[0][$variable]) {
            echo '<span class="allfine">';
        } else {
            echo '<span>';
        }
        // allow wrapping long table lists into multiple lines
        static $variables_wrap = array('Replicate_Do_DB', 'Replicate_Ignore_DB', 'Replicate_Do_Table', 'Replicate_Ignore_Table', 'Replicate_Wild_Do_Table', 'Replicate_Wild_Ignore_Table');
        if (in_array($variable, $variables_wrap)) {
            echo str_replace(',', ', ', ${"server_{$type}_replication"}[0][$variable]);
        } else {
            echo ${"server_{$type}_replication"}[0][$variable];
        }
        echo '</span>';
        echo '  </td>';
        echo ' </tr>';
        $odd_row = !$odd_row;
    }
    echo '   </tbody>';
    echo ' </table>';
    echo ' <br />';
    echo '</div>';
}
/**
 * Prints table with slave users connected to this master
 *
 * @param boolean $hidden - if true, then default style is set to hidden, default value false
 *
 * @return void
 */
function PMA_replication_print_slaves_table($hidden = false)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_replication_print_slaves_table") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php at line 187")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_replication_print_slaves_table:187@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php');
    die();
}
/**
 * get the correct username and hostname lengths for this MySQL server
 *
 * @return array   username length, hostname length
 */
function PMA_replication_get_username_hostname_length()
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_replication_get_username_hostname_length") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php at line 226")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_replication_get_username_hostname_length:226@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php');
    die();
}
/**
 * Print code to add a replication slave user to the master
 *
 * @return void
 */
function PMA_replication_gui_master_addslaveuser()
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_replication_gui_master_addslaveuser") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php at line 255")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_replication_gui_master_addslaveuser:255@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/replication_gui.lib.php');
    die();
}