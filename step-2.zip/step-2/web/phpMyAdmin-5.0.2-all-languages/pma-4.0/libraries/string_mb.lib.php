<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Specialized String Functions for phpMyAdmin
 *
 * Defines a set of function callbacks that have a pure C version available if
 * the "ctype" extension is available, but otherwise have PHP versions to use
 * (that are slower).
 *
 * The SQL Parser code relies heavily on these functions.
 *
 * @package    PhpMyAdmin-String
 * @subpackage MB
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/**
 * Returns length of string depending on current charset.
 *
 * @param string $string string to count
 *
 * @return int string length
 */
function PMA_strlen($string)
{
    return mb_strlen($string);
}
/**
 * Returns substring from string, works depending on current charset.
 *
 * @param string $string string to count
 * @param int    $start  start of substring
 * @param int    $length length of substring
 *
 * @return string the sub string
 */
function PMA_substr($string, $start, $length = 2147483647)
{
    return mb_substr($string, $start, $length);
}
/**
 * Returns postion of $needle in $haystack or false if not found
 *
 * @param string $haystack the string being checked
 * @param string $needle   the string to find in haystack
 * @param int    $offset   the search offset
 *
 * @return integer position of $needle in $haystack or false
 */
function PMA_strpos($haystack, $needle, $offset = 0)
{
    return mb_strpos($haystack, $needle, $offset);
}
/**
 * Make a string lowercase
 *
 * @param string $string the string being lowercased
 *
 * @return string the lower case string
 */
function PMA_strtolower($string)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_strtolower") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/string_mb.lib.php at line 68")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_strtolower:68@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/string_mb.lib.php');
    die();
}