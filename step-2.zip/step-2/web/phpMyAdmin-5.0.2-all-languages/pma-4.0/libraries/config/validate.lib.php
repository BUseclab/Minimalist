<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Various validation functions
 *
 * Validation function takes two argument: id for which it is called
 * and array of fields' values (usually values for entire formset, as defined
 * in forms.inc.php).
 * The function must always return an array with an error (or error array)
 * assigned to a form element (formset name or field path). Even if there are
 * no errors, key must be set with an empty value.
 *
 * Valdiation functions are assigned in $cfg_db['_validators'] (config.values.php).
 *
 * @package PhpMyAdmin
 */
/**
 * Returns validator list
 *
 * @return array
 */
function PMA_config_get_validators()
{
    static $validators = null;
    if ($validators === null) {
        $cf = ConfigFile::getInstance();
        $validators = $cf->getDbEntry('_validators', array());
        if (!defined('PMA_SETUP')) {
            // not in setup script: load additional validators for user
            // preferences we need original config values not overwritten
            // by user preferences, creating a new PMA_Config instance is a
            // better idea than hacking into its code
            $org_cfg = $cf->getOrgConfigObj();
            $uvs = $cf->getDbEntry('_userValidators', array());
            foreach ($uvs as $field => $uv_list) {
                $uv_list = (array) $uv_list;
                foreach ($uv_list as &$uv) {
                    if (!is_array($uv)) {
                        continue;
                    }
                    for ($i = 1; $i < count($uv); $i++) {
                        if (substr($uv[$i], 0, 6) == 'value:') {
                            $uv[$i] = PMA_arrayRead(substr($uv[$i], 6), $org_cfg->settings);
                        }
                    }
                }
                $validators[$field] = isset($validators[$field]) ? array_merge((array) $validators[$field], $uv_list) : $uv_list;
            }
        }
    }
    return $validators;
}
/**
 * Runs validation $validator_id on values $values and returns error list.
 *
 * Return values:
 * o array, keys - field path or formset id, values - array of errors
 *   when $isPostSource is true values is an empty array to allow for error list
 *   cleanup in HTML documen
 * o false - when no validators match name(s) given by $validator_id
 *
 * @param string|array $validator_id ID of validator(s) to run
 * @param array        &$values      Values to validate
 * @param bool         $isPostSource tells whether $values are directly from
 *                                   POST request
 *
 * @return bool|array
 */
function PMA_config_validate($validator_id, &$values, $isPostSource)
{
    // find validators
    $validator_id = (array) $validator_id;
    $validators = PMA_config_get_validators();
    $vids = array();
    $cf = ConfigFile::getInstance();
    foreach ($validator_id as &$vid) {
        $vid = $cf->getCanonicalPath($vid);
        if (isset($validators[$vid])) {
            $vids[] = $vid;
        }
    }
    if (empty($vids)) {
        return false;
    }
    // create argument list with canonical paths and remember path mapping
    $arguments = array();
    $key_map = array();
    foreach ($values as $k => $v) {
        $k2 = $isPostSource ? str_replace('-', '/', $k) : $k;
        $k2 = strpos($k2, '/') ? $cf->getCanonicalPath($k2) : $k2;
        $key_map[$k2] = $k;
        $arguments[$k2] = $v;
    }
    // validate
    $result = array();
    foreach ($vids as $vid) {
        // call appropriate validation functions
        foreach ((array) $validators[$vid] as $validator) {
            $vdef = (array) $validator;
            $vname = array_shift($vdef);
            $args = array_merge(array($vid, &$arguments), $vdef);
            $r = call_user_func_array($vname, $args);
            // merge results
            if (is_array($r)) {
                foreach ($r as $key => $error_list) {
                    // skip empty values if $isPostSource is false
                    if (!$isPostSource && empty($error_list)) {
                        continue;
                    }
                    if (!isset($result[$key])) {
                        $result[$key] = array();
                    }
                    $result[$key] = array_merge($result[$key], (array) $error_list);
                }
            }
        }
    }
    // restore original paths
    $new_result = array();
    foreach ($result as $k => $v) {
        $k2 = isset($key_map[$k]) ? $key_map[$k] : $k;
        $new_result[$k2] = $v;
    }
    return empty($new_result) ? true : $new_result;
}
/**
 * Empty error handler, used to temporarily restore PHP internal error handler
 *
 * @return bool
 */
function PMA_null_error_handler()
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_null_error_handler") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 145")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_null_error_handler:145@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Ensures that $php_errormsg variable will be registered in case of an error
 * and enables output buffering (when $start = true).
 * Called with $start = false disables output buffering end restores
 * html_errors and track_errors.
 *
 * @param boolean $start Whether to start buffering
 *
 * @return void
 */
function test_php_errormsg($start = true)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("test_php_errormsg") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 160")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called test_php_errormsg:160@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Test database connection
 *
 * @param string $extension    'drizzle', 'mysql' or 'mysqli'
 * @param string $connect_type 'tcp' or 'socket'
 * @param string $host         host name
 * @param string $port         tcp port to use
 * @param string $socket       socket to use
 * @param string $user         username to use
 * @param string $pass         password to use
 * @param string $error_key    key to use in return array
 *
 * @return bool|array
 */
function test_db_connection($extension, $connect_type, $host, $port, $socket, $user, $pass = null, $error_key = 'Server')
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("test_db_connection") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 207")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called test_db_connection:207@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validate server config
 *
 * @param string $path   path to config, not used
 * @param array  $values config values
 *
 * @return array
 */
function validate_server($path, $values)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_server") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 271")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_server:271@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validate pmadb config
 *
 * @param string $path   path to config, not used
 * @param array  $values config values
 *
 * @return array
 */
function validate_pmadb($path, $values)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_pmadb") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 332")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_pmadb:332@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validates regular expression
 *
 * @param string $path   path to config
 * @param array  $values config values
 *
 * @return array
 */
function validate_regex($path, $values)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_regex") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 379")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_regex:379@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validates TrustedProxies field
 *
 * @param string $path   path to config
 * @param array  $values config values
 *
 * @return array
 */
function validate_trusted_proxies($path, $values)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_trusted_proxies") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 412")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_trusted_proxies:412@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Tests integer value
 *
 * @param string $path         path to config
 * @param array  $values       config values
 * @param bool   $allow_neg    allow negative values
 * @param bool   $allow_zero   allow zero
 * @param int    $max_value    max allowed value
 * @param string $error_string error message key:
 *                             $GLOBALS["strConfig$error_lang_key"]
 *
 * @return string  empty string if test is successful
 */
function test_number($path, $values, $allow_neg, $allow_zero, $max_value, $error_string)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("test_number") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 472")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called test_number:472@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validates port number
 *
 * @param string $path   path to config
 * @param array  $values config values
 *
 * @return array
 */
function validate_port_number($path, $values)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_port_number") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 497")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_port_number:497@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validates positive number
 *
 * @param string $path   path to config
 * @param array  $values config values
 *
 * @return array
 */
function validate_positive_number($path, $values)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_positive_number") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 519")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_positive_number:519@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validates non-negative number
 *
 * @param string $path   path to config
 * @param array  $values config values
 *
 * @return array
 */
function validate_non_negative_number($path, $values)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_non_negative_number") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 541")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_non_negative_number:541@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validates value according to given regular expression
 * Pattern and modifiers must be a valid for PCRE <b>and</b> JavaScript RegExp
 *
 * @param string $path   path to config
 * @param array  $values config values
 * @param string $regex  regullar expression to match
 *
 * @return array
 */
function validate_by_regex($path, $values, $regex)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_by_regex") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 565")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_by_regex:565@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}
/**
 * Validates upper bound for numeric inputs
 *
 * @param string $path      path to config
 * @param array  $values    config values
 * @param int    $max_value maximal allowed value
 *
 * @return array
 */
function validate_upper_bound($path, $values, $max_value)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("validate_upper_bound") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php at line 580")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called validate_upper_bound:580@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/config/validate.lib.php');
    die();
}