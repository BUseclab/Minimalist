<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Abstract class for the date format transformations plugins
 *
 * @package    PhpMyAdmin-Transformations
 * @subpackage DateFormat
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/* Get the transformations interface */
require_once 'libraries/plugins/TransformationsPlugin.class.php';
/**
 * Provides common methods for all of the date format transformations plugins.
 *
 * @package PhpMyAdmin
 */
abstract class DateFormatTransformationsPlugin extends TransformationsPlugin
{
    /**
     * Gets the transformation description of the specific plugin
     *
     * @return string
     */
    public static function getInfo()
    {
        echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("getInfo") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/plugins/transformations/abstract/DateFormatTransformationsPlugin.class.php at line 30")                </p>            </div>        </div>    </div></body></html>');
        error_log('Removed function called getInfo:30@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/plugins/transformations/abstract/DateFormatTransformationsPlugin.class.php');
        die();
    }
    /**
     * Does the actual work of each specific transformations plugin.
     *
     * @param string $buffer  text to be transformed
     * @param array  $options transformation options
     * @param string $meta    meta information
     *
     * @return void
     */
    public function applyTransformation($buffer, $options = array(), $meta = '')
    {
        // possibly use a global transform and feed it with special options
        // further operations on $buffer using the $options[] array.
        if (empty($options[0])) {
            $options[0] = 0;
        }
        if (empty($options[2])) {
            $options[2] = 'local';
        } else {
            $options[2] = strtolower($options[2]);
        }
        if (empty($options[1])) {
            if ($options[2] == 'local') {
                $options[1] = __('%B %d, %Y at %I:%M %p');
            } else {
                $options[1] = 'Y-m-d  H:i:s';
            }
        }
        $timestamp = -1;
        // INT columns will be treated as UNIX timestamps
        // and need to be detected before the verification for
        // MySQL TIMESTAMP
        if ($meta->type == 'int') {
            $timestamp = $buffer;
            // Detect TIMESTAMP(6 | 8 | 10 | 12 | 14)
            // TIMESTAMP (2 | 4) not supported here.
            // (Note: prior to MySQL 4.1, TIMESTAMP has a display size
            // for example TIMESTAMP(8) means YYYYMMDD)
        } else {
            if (preg_match('/^(\\d{2}){3,7}$/', $buffer)) {
                if (strlen($buffer) == 14 || strlen($buffer) == 8) {
                    $offset = 4;
                } else {
                    $offset = 2;
                }
                $d = array();
                $d['year'] = substr($buffer, 0, $offset);
                $d['month'] = substr($buffer, $offset, 2);
                $d['day'] = substr($buffer, $offset + 2, 2);
                $d['hour'] = substr($buffer, $offset + 4, 2);
                $d['minute'] = substr($buffer, $offset + 6, 2);
                $d['second'] = substr($buffer, $offset + 8, 2);
                if (checkdate($d['month'], $d['day'], $d['year'])) {
                    $timestamp = mktime($d['hour'], $d['minute'], $d['second'], $d['month'], $d['day'], $d['year']);
                }
                // If all fails, assume one of the dozens of valid strtime() syntaxes
                // (http://www.gnu.org/manual/tar-1.12/html_chapter/tar_7.html)
            } else {
                if (preg_match('/^[0-9]\\d{1,9}$/', $buffer)) {
                    $timestamp = (int) $buffer;
                } else {
                    $timestamp = strtotime($buffer);
                }
            }
        }
        // If all above failed, maybe it's a Unix timestamp already?
        if ($timestamp < 0 && preg_match('/^[1-9]\\d{1,9}$/', $buffer)) {
            $timestamp = $buffer;
        }
        // Reformat a valid timestamp
        if ($timestamp >= 0) {
            $timestamp -= $options[0] * 60 * 60;
            $source = $buffer;
            if ($options[2] == 'local') {
                $text = PMA_Util::localisedDate($timestamp, $options[1]);
            } elseif ($options[2] == 'utc') {
                $text = gmdate($options[1], $timestamp);
            } else {
                $text = 'INVALID DATE TYPE';
            }
            $buffer = '<dfn onclick="alert(\'' . $source . '\');" title="' . $source . '">' . $text . '</dfn>';
        }
        return $buffer;
    }
    /**
     * This method is called when any PluginManager to which the observer
     * is attached calls PluginManager::notify()
     *
     * @param SplSubject $subject The PluginManager notifying the observer
     *                            of an update.
     *
     * @todo implement
     * @return void
     */
    public function update(SplSubject $subject)
    {
    }
    /* ~~~~~~~~~~~~~~~~~~~~ Getters and Setters ~~~~~~~~~~~~~~~~~~~~ */
    /**
     * Gets the transformation name of the specific plugin
     *
     * @return string
     */
    public static function getName()
    {
        return "Date Format";
    }
}