<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Abstract class for the hex transformations plugins
 *
 * @package    PhpMyAdmin-Transformations
 * @subpackage Hex
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/* Get the transformations interface */
require_once 'libraries/plugins/TransformationsPlugin.class.php';
/**
 * Provides common methods for all of the hex transformations plugins.
 *
 * @package PhpMyAdmin
 */
abstract class HexTransformationsPlugin extends TransformationsPlugin
{
    /**
     * Gets the transformation description of the specific plugin
     *
     * @return string
     */
    public static function getInfo()
    {
        echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("getInfo") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/plugins/transformations/abstract/HexTransformationsPlugin.class.php at line 30")                </p>            </div>        </div>    </div></body></html>');
        error_log('Removed function called getInfo:30@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/plugins/transformations/abstract/HexTransformationsPlugin.class.php');
        die();
    }
    /**
     * Does the actual work of each specific transformations plugin.
     *
     * @param string $buffer  text to be transformed
     * @param array  $options transformation options
     * @param string $meta    meta information
     *
     * @return void
     */
    public function applyTransformation($buffer, $options = array(), $meta = '')
    {
        // possibly use a global transform and feed it with special options
        if (!isset($options[0])) {
            $options[0] = 2;
        } else {
            $options[0] = (int) $options[0];
        }
        if ($options[0] < 1) {
            return bin2hex($buffer);
        } else {
            return chunk_split(bin2hex($buffer), $options[0], ' ');
        }
    }
    /**
     * This method is called when any PluginManager to which the observer
     * is attached calls PluginManager::notify()
     *
     * @param SplSubject $subject The PluginManager notifying the observer
     *                            of an update.
     *
     * @todo implement
     * @return void
     */
    public function update(SplSubject $subject)
    {
    }
    /* ~~~~~~~~~~~~~~~~~~~~ Getters and Setters ~~~~~~~~~~~~~~~~~~~~ */
    /**
     * Gets the transformation name of the specific plugin
     *
     * @return string
     */
    public static function getName()
    {
        return "Hex";
    }
}