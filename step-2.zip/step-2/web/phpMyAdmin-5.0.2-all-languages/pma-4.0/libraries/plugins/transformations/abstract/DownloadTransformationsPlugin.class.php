<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Abstract class for the download transformations plugins
 *
 * @package    PhpMyAdmin-Transformations
 * @subpackage Download
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/* Get the transformations interface */
require_once 'libraries/plugins/TransformationsPlugin.class.php';
/**
 * Provides common methods for all of the download transformations plugins.
 *
 * @package PhpMyAdmin
 */
abstract class DownloadTransformationsPlugin extends TransformationsPlugin
{
    /**
     * Gets the transformation description of the specific plugin
     *
     * @return string
     */
    public static function getInfo()
    {
        echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("getInfo") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/plugins/transformations/abstract/DownloadTransformationsPlugin.class.php at line 30")                </p>            </div>        </div>    </div></body></html>');
        error_log('Removed function called getInfo:30@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/plugins/transformations/abstract/DownloadTransformationsPlugin.class.php');
        die();
    }
    /**
     * Does the actual work of each specific transformations plugin.
     *
     * @param string $buffer  text to be transformed
     * @param array  $options transformation options
     * @param string $meta    meta information
     *
     * @return void
     */
    public function applyTransformation($buffer, $options = array(), $meta = '')
    {
        global $row, $fields_meta;
        if (isset($options[0]) && !empty($options[0])) {
            $cn = $options[0];
            // filename
        } else {
            if (isset($options[1]) && !empty($options[1])) {
                foreach ($fields_meta as $key => $val) {
                    if ($val->name == $options[1]) {
                        $pos = $key;
                        break;
                    }
                }
                if (isset($pos)) {
                    $cn = $row[$pos];
                }
            }
            if (empty($cn)) {
                $cn = 'binary_file.dat';
            }
        }
        return sprintf('<a href="transformation_wrapper.php%s&amp;ct=application' . '/octet-stream&amp;cn=%s" title="%s">%s</a>', $options['wrapper_link'], urlencode($cn), htmlspecialchars($cn), htmlspecialchars($cn));
    }
    /**
     * This method is called when any PluginManager to which the observer
     * is attached calls PluginManager::notify()
     *
     * @param SplSubject $subject The PluginManager notifying the observer
     *                            of an update.
     *
     * @todo implement
     * @return void
     */
    public function update(SplSubject $subject)
    {
    }
    /* ~~~~~~~~~~~~~~~~~~~~ Getters and Setters ~~~~~~~~~~~~~~~~~~~~ */
    /**
     * Gets the transformation name of the specific plugin
     *
     * @return string
     */
    public static function getName()
    {
        return "Download";
    }
}