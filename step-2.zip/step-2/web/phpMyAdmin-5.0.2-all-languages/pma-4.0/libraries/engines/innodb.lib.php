<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * The InnoDB storage engine
 *
 * @package PhpMyAdmin-Engines
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/**
 * The InnoDB storage engine
 *
 * @package PhpMyAdmin-Engines
 */
class PMA_StorageEngine_innodb extends PMA_StorageEngine
{
    /**
     * Returns array with variable names related to InnoDB storage engine
     *
     * @return array   variable names
     */
    function getVariables()
    {
        echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("getVariables") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/engines/innodb.lib.php at line 26")                </p>            </div>        </div>    </div></body></html>');
        error_log('Removed function called getVariables:26@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/engines/innodb.lib.php');
        die();
    }
    /**
     * Returns the pattern to be used in the query for SQL variables
     * related to InnoDb storage engine
     *
     * @return string  SQL query LIKE pattern
     */
    function getVariablesLikePattern()
    {
        echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("getVariablesLikePattern") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/engines/innodb.lib.php at line 129")                </p>            </div>        </div>    </div></body></html>');
        error_log('Removed function called getVariablesLikePattern:129@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/engines/innodb.lib.php');
        die();
    }
    /**
     * Get information pages
     *
     * @return array detail pages
     */
    function getInfoPages()
    {
        if ($this->support < PMA_ENGINE_SUPPORT_YES) {
            return array();
        }
        $pages = array();
        $pages['Bufferpool'] = __('Buffer Pool');
        $pages['Status'] = __('InnoDB Status');
        return $pages;
    }
    /**
     * returns html tables with stats over inno db buffer pool
     *
     * @return string  html table with stats
     */
    function getPageBufferpool()
    {
        // The following query is only possible because we know
        // that we are on MySQL 5 here (checked above)!
        // side note: I love MySQL 5 for this. :-)
        $sql = '
             SHOW STATUS
            WHERE Variable_name LIKE \'Innodb\\_buffer\\_pool\\_%\'
               OR Variable_name = \'Innodb_page_size\';';
        $status = PMA_DBI_fetch_result($sql, 0, 1);
        $output = '<table class="data" id="table_innodb_bufferpool_usage">' . "\n" . '    <caption class="tblHeaders">' . "\n" . '        ' . __('Buffer Pool Usage') . "\n" . '    </caption>' . "\n" . '    <tfoot>' . "\n" . '        <tr>' . "\n" . '            <th colspan="2">' . "\n" . '                ' . __('Total') . "\n" . '                : ' . PMA_Util::formatNumber($status['Innodb_buffer_pool_pages_total'], 0) . '&nbsp;' . __('pages') . ' / ' . join('&nbsp;', PMA_Util::formatByteDown($status['Innodb_buffer_pool_pages_total'] * $status['Innodb_page_size'])) . "\n" . '            </th>' . "\n" . '        </tr>' . "\n" . '    </tfoot>' . "\n" . '    <tbody>' . "\n" . '        <tr class="odd">' . "\n" . '            <th>' . __('Free pages') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_pages_free'], 0) . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="even">' . "\n" . '            <th>' . __('Dirty pages') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_pages_dirty'], 0) . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="odd">' . "\n" . '            <th>' . __('Pages containing data') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_pages_data'], 0) . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="even">' . "\n" . '            <th>' . __('Pages to be flushed') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_pages_flushed'], 0) . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="odd">' . "\n" . '            <th>' . __('Busy pages') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_pages_misc'], 0) . "\n" . '</td>' . "\n" . '        </tr>';
        // not present at least since MySQL 5.1.40
        if (isset($status['Innodb_buffer_pool_pages_latched'])) {
            $output .= '        <tr class="even">' . '            <th>' . __('Latched pages') . '</th>' . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_pages_latched'], 0) . '</td>' . '        </tr>';
        }
        $output .= '    </tbody>' . "\n" . '</table>' . "\n\n" . '<table class="data" id="table_innodb_bufferpool_activity">' . "\n" . '    <caption class="tblHeaders">' . "\n" . '        ' . __('Buffer Pool Activity') . "\n" . '    </caption>' . "\n" . '    <tbody>' . "\n" . '        <tr class="odd">' . "\n" . '            <th>' . __('Read requests') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_read_requests'], 0) . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="even">' . "\n" . '            <th>' . __('Write requests') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_write_requests'], 0) . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="odd">' . "\n" . '            <th>' . __('Read misses') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_reads'], 0) . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="even">' . "\n" . '            <th>' . __('Write waits') . '</th>' . "\n" . '            <td class="value">' . PMA_Util::formatNumber($status['Innodb_buffer_pool_wait_free'], 0) . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="odd">' . "\n" . '            <th>' . __('Read misses in %') . '</th>' . "\n" . '            <td class="value">' . ($status['Innodb_buffer_pool_read_requests'] == 0 ? '---' : htmlspecialchars(PMA_Util::formatNumber($status['Innodb_buffer_pool_reads'] * 100 / $status['Innodb_buffer_pool_read_requests'], 3, 2)) . ' %') . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '        <tr class="even">' . "\n" . '            <th>' . __('Write waits in %') . '</th>' . "\n" . '            <td class="value">' . ($status['Innodb_buffer_pool_write_requests'] == 0 ? '---' : htmlspecialchars(PMA_Util::formatNumber($status['Innodb_buffer_pool_wait_free'] * 100 / $status['Innodb_buffer_pool_write_requests'], 3, 2)) . ' %') . "\n" . '</td>' . "\n" . '        </tr>' . "\n" . '    </tbody>' . "\n" . '</table>' . "\n";
        return $output;
    }
    /**
     * returns InnoDB status
     *
     * @return string  result of SHOW INNODB STATUS inside pre tags
     */
    function getPageStatus()
    {
        return '<pre id="pre_innodb_status">' . "\n" . htmlspecialchars(PMA_DBI_fetch_value('SHOW INNODB STATUS;', 0, 'Status')) . "\n" . '</pre>' . "\n";
    }
    /**
     * Returns content for page $id
     *
     * @param string $id page id
     *
     * @return string html output
     */
    function getPage($id)
    {
        if (!array_key_exists($id, $this->getInfoPages())) {
            return false;
        }
        $id = 'getPage' . $id;
        return $this->{$id}();
    }
    /**
     * returns string with filename for the MySQL helppage
     * about this storage engine
     *
     * @return string  mysql helppage filename
     */
    function getMysqlHelpPage()
    {
        return 'innodb-storage-engine';
    }
    /**
     * Gets the InnoDB plugin version number
     *
     * http://www.innodb.com/products/innodb_plugin
     * (do not confuse this with phpMyAdmin's storage engine plugins!)
     *
     * @return string the version number, or empty if not running as a plugin
     */
    function getInnodbPluginVersion()
    {
        return PMA_DBI_fetch_value('SELECT @@innodb_version;');
    }
    /**
     * Gets the InnoDB file format
     *
     * (works only for the InnoDB plugin)
     * http://www.innodb.com/products/innodb_plugin
     * (do not confuse this with phpMyAdmin's storage engine plugins!)
     *
     * @return string the InnoDB file format
     */
    function getInnodbFileFormat()
    {
        return PMA_DBI_fetch_value("SHOW GLOBAL VARIABLES LIKE 'innodb_file_format';", 0, 1);
    }
    /**
     * Verifies if this server supports the innodb_file_per_table feature
     *
     * (works only for the InnoDB plugin)
     * http://www.innodb.com/products/innodb_plugin
     * (do not confuse this with phpMyAdmin's storage engine plugins!)
     *
     * @return boolean whether this feature is supported or not
     */
    function supportsFilePerTable()
    {
        $innodb_file_per_table = PMA_DBI_fetch_value("SHOW GLOBAL VARIABLES LIKE 'innodb_file_per_table';", 0, 1);
        if ($innodb_file_per_table == 'ON') {
            return true;
        } else {
            return false;
        }
    }
}