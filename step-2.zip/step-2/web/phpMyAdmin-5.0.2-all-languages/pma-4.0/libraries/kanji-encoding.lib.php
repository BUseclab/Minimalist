<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Set of functions for kanji-encoding convert (available only with japanese
 * language)
 *
 * PHP4 configure requirements:
 *     --enable-mbstring --enable-mbstr-enc-trans --enable-mbregex
 *
 * 2002/2/22 - by Yukihiro Kawada <kawada@den.fujifilm.co.jp>
 *
 * @package PhpMyAdmin
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/**
 * Gets the php internal encoding codes and sets the available encoding
 * codes list
 * 2002/1/4 by Y.Kawada
 *
 * @global  string   the current encoding code
 * @global  string   the available encoding codes list
 *
 * @return boolean  always true
 */
function PMA_internal_enc_check()
{
    global $internal_enc, $enc_list;
    $internal_enc = mb_internal_encoding();
    if ($internal_enc == 'EUC-JP') {
        $enc_list = 'ASCII,EUC-JP,SJIS,JIS';
    } else {
        $enc_list = 'ASCII,SJIS,EUC-JP,JIS';
    }
    return true;
}
// end of the 'PMA_internal_enc_check' function
/**
 * Reverses SJIS & EUC-JP position in the encoding codes list
 * 2002/1/4 by Y.Kawada
 *
 * @global  string   the available encoding codes list
 *
 * @return boolean  always true
 */
function PMA_change_enc_order()
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_change_enc_order") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/kanji-encoding.lib.php at line 53")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_change_enc_order:53@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/kanji-encoding.lib.php');
    die();
}
// end of the 'PMA_change_enc_order' function
/**
 * Kanji string encoding convert
 * 2002/1/4 by Y.Kawada
 *
 * @param string $str  the string to convert
 * @param string $enc  the destination encoding code
 * @param string $kana set 'kana' convert to JIS-X208-kana
 *
 * @global  string   the available encoding codes list
 *
 * @return string   the converted string
 */
function PMA_kanji_str_conv($str, $enc, $kana)
{
    global $enc_list;
    if ($enc == '' && $kana == '') {
        return $str;
    }
    $nw = mb_detect_encoding($str, $enc_list);
    if ($kana == 'kana') {
        $dist = mb_convert_kana($str, 'KV', $nw);
        $str = $dist;
    }
    if ($nw != $enc && $enc != '') {
        $dist = mb_convert_encoding($str, $enc, $nw);
    } else {
        $dist = $str;
    }
    return $dist;
}
// end of the 'PMA_kanji_str_conv' function
/**
 * Kanji file encoding convert
 * 2002/1/4 by Y.Kawada
 *
 * @param string $file the name of the file to convert
 * @param string $enc  the destination encoding code
 * @param string $kana set 'kana' convert to JIS-X208-kana
 *
 * @return string   the name of the converted file
 */
function PMA_kanji_file_conv($file, $enc, $kana)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_kanji_file_conv") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/kanji-encoding.lib.php at line 112")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_kanji_file_conv:112@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/kanji-encoding.lib.php');
    die();
}
// end of the 'PMA_kanji_file_conv' function
/**
 * Defines radio form fields to switch between encoding modes
 * 2002/1/4 by Y.Kawada
 *
 * @param string $spaces spaces character to prepend the output with
 *
 * @return string   xhtml code for the radio controls
 */
function PMA_set_enc_form($spaces)
{
    return "\n" . $spaces . '<ul>' . "\n" . '<li>' . $spaces . '<input type="radio" name="knjenc" value="" checked="checked" id="kj-none" /><label for="kj-none">' . _pgettext('None encoding conversion', 'None') . "</label>\n" . $spaces . '<input type="radio" name="knjenc" value="EUC-JP" id="kj-euc" /><label for="kj-euc">EUC</label>' . "\n" . $spaces . '<input type="radio" name="knjenc" value="SJIS" id="kj-sjis" /><label for="kj-sjis">SJIS</label>' . "\n" . $spaces . '</li>' . "\n" . '<li>' . $spaces . '<input type="checkbox" name="xkana" value="kana" id="kj-kana" />' . "\n" . $spaces . '<label for="kj-kana">' . __('Convert to Kana') . '</label><br />' . "\n" . $spaces . '</li>' . "\n" . '</ul>';
}
// end of the 'PMA_set_enc_form' function
PMA_internal_enc_check();