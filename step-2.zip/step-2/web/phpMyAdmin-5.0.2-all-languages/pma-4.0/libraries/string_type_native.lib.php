<?php

/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Specialized String Functions for phpMyAdmin
 *
 * Defines a set of function callbacks that have a pure C version available if
 * the "ctype" extension is available, but otherwise have PHP versions to use
 * (that are slower).
 *
 * The SQL Parser code relies heavily on these functions.
 *
 * @package    PhpMyAdmin-String
 * @subpackage Native
 */
if (!defined('PHPMYADMIN')) {
    exit;
}
/**
 * Checks if a character is an alphanumeric one
 *
 * @param string $c character to check for
 *
 * @return boolean whether the character is an alphanumeric one or not
 */
function PMA_STR_isAlnum($c)
{
    return PMA_STR_isUpper($c) || PMA_STR_isLower($c) || PMA_STR_isDigit($c);
}
// end of the "PMA_STR_isAlnum()" function
/**
 * Checks if a character is an alphabetic one
 *
 * @param string $c character to check for
 *
 * @return boolean whether the character is an alphabetic one or not
 */
function PMA_STR_isAlpha($c)
{
    echo('<html><head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    <title>Error, Target Function Has Been Removed</title>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">    <style>        * {            font-family: tahoma;        }        div.container .panel {            position: relative !important;        }        div.container {            width: 50% !important;            height: 50% !important;            overflow: auto !important;            margin: auto !important;            position: absolute !important;            top: 0 !important;            left: 0 !important;            bottom: 0 !important;            right: 0 !important;        }    </style></head><body>    <div class="container">        <div class="panel panel-danger center">            <div class="panel-heading" style="text-align: left;"> Error </div>            <div class="panel-body">                <p class="text-center">                  This function has been removed ("PMA_STR_isAlpha") from ("/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/string_type_native.lib.php at line 40")                </p>            </div>        </div>    </div></body></html>');
    error_log('Removed function called PMA_STR_isAlpha:40@/var/www/html/phpMyAdmin-4.0.0-all-languages/libraries/string_type_native.lib.php');
    die();
}
// end of the "PMA_STR_isAlpha()" function
/**
 * Checks if a character is a digit
 *
 * @param string $c character to check for
 *
 * @return boolean whether the character is a digit or not
 */
function PMA_STR_isDigit($c)
{
    $ord_zero = 48;
    //ord('0');
    $ord_nine = 57;
    //ord('9');
    $ord_c = ord($c);
    return PMA_STR_numberInRangeInclusive($ord_c, $ord_zero, $ord_nine);
}
// end of the "PMA_STR_isDigit()" function
/**
 * Checks if a character is an upper alphabetic one
 *
 * @param string $c character to check for
 *
 * @return boolean whether the character is an upper alphabetic one or not
 */
function PMA_STR_isUpper($c)
{
    $ord_zero = 65;
    //ord('A');
    $ord_nine = 90;
    //ord('Z');
    $ord_c = ord($c);
    return PMA_STR_numberInRangeInclusive($ord_c, $ord_zero, $ord_nine);
}
// end of the "PMA_STR_isUpper()" function
/**
 * Checks if a character is a lower alphabetic one
 *
 * @param string $c character to check for
 *
 * @return boolean whether the character is a lower alphabetic one or not
 */
function PMA_STR_isLower($c)
{
    $ord_zero = 97;
    //ord('a');
    $ord_nine = 122;
    //ord('z');
    $ord_c = ord($c);
    return PMA_STR_numberInRangeInclusive($ord_c, $ord_zero, $ord_nine);
}
// end of the "PMA_STR_isLower()" function
/**
 * Checks if a character is a space one
 *
 * @param string $c character to check for
 *
 * @return boolean whether the character is a space one or not
 */
function PMA_STR_isSpace($c)
{
    $ord_space = 32;
    //ord(' ')
    $ord_tab = 9;
    //ord('\t')
    $ord_CR = 13;
    //ord('\n')
    $ord_NOBR = 160;
    //ord('U+00A0);
    $ord_c = ord($c);
    return $ord_c == $ord_space || $ord_c == $ord_NOBR || PMA_STR_numberInRangeInclusive($ord_c, $ord_tab, $ord_CR);
}
// end of the "PMA_STR_isSpace()" function
/**
 * Checks if a character is an hexadecimal digit
 *
 * @param string $c character to check for
 *
 * @return boolean whether the character is an hexadecimal digit or not
 */
function PMA_STR_isHexDigit($c)
{
    $ord_Aupper = 65;
    //ord('A');
    $ord_Fupper = 70;
    //ord('F');
    $ord_Alower = 97;
    //ord('a');
    $ord_Flower = 102;
    //ord('f');
    $ord_zero = 48;
    //ord('0');
    $ord_nine = 57;
    //ord('9');
    $ord_c = ord($c);
    return PMA_STR_numberInRangeInclusive($ord_c, $ord_zero, $ord_nine) || PMA_STR_numberInRangeInclusive($ord_c, $ord_Aupper, $ord_Fupper) || PMA_STR_numberInRangeInclusive($ord_c, $ord_Alower, $ord_Flower);
}
// end of the "PMA_STR_isHexDigit()" function