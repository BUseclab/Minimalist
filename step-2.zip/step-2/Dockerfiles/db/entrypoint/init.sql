-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: Sep 14, 2020 at 03:25 PM
-- Server version: 5.7.29
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `code_coverage`
--
CREATE DATABASE IF NOT EXISTS `code_coverage` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `code_coverage`;

-- --------------------------------------------------------

--
-- Table structure for table `covered_files`
--

DROP TABLE IF EXISTS `covered_files`;
CREATE TABLE `covered_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(400) NOT NULL,
  `fk_test_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `covered_files`
--



-- --------------------------------------------------------

--
-- Table structure for table `covered_lines`
--

DROP TABLE IF EXISTS `covered_lines`;
CREATE TABLE `covered_lines` (
  `id` int(11) NOT NULL,
  `line_number` int(11) NOT NULL,
  `run` int(11) NOT NULL,
  `fk_file_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `covered_lines`
--


-- --------------------------------------------------------

--
-- Table structure for table `included_files`
--

DROP TABLE IF EXISTS `included_files`;
CREATE TABLE `included_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(400) CHARACTER SET utf8 NOT NULL,
  `fk_test_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
CREATE TABLE `software` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `software`
--

INSERT INTO `software` (`id`, `name`) VALUES
(1, 'phpMyAdmin'),
(2, 'MediaWiki'),
(3, 'Magento'),
(4, 'Wordpress');

-- --------------------------------------------------------

--
-- Table structure for table `software_files`
--

DROP TABLE IF EXISTS `software_files`;
CREATE TABLE `software_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(400) CHARACTER SET utf8 NOT NULL,
  `line_count` int(11) DEFAULT '-1',
  `removed` tinyint(4) DEFAULT NULL,
  `fk_software_files_description` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `software_files`
--


-- --------------------------------------------------------

--
-- Table structure for table `software_files_description`
--

DROP TABLE IF EXISTS `software_files_description`;
CREATE TABLE `software_files_description` (
  `id` int(11) NOT NULL,
  `description` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `fk_software_id` int(11) NOT NULL,
  `fk_software_version_id` int(11) NOT NULL,
  `software_files_descriptioncol` varchar(45) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `software_files_description`
--

-- --------------------------------------------------------

--
-- Table structure for table `software_functions`
--

DROP TABLE IF EXISTS `software_functions`;
CREATE TABLE `software_functions` (
  `id` int(11) NOT NULL,
  `fk_software_file` int(11) DEFAULT '-1',
  `function_name` varchar(150) DEFAULT NULL,
  `line_number` int(11) DEFAULT NULL,
  `line_count` int(11) DEFAULT '-1',
  `removed` tinyint(4) NOT NULL DEFAULT '-1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `software_functions`
--


-- --------------------------------------------------------

--
-- Table structure for table `software_version`
--

DROP TABLE IF EXISTS `software_version`;
CREATE TABLE `software_version` (
  `id` int(11) NOT NULL,
  `version` varchar(100) NOT NULL,
  `fk_software_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `software_version`
--

INSERT INTO `software_version` (`id`, `version`, `fk_software_id`) VALUES
(1, '4.0.0', 1),
(2, '4.4.0', 1),
(3, '4.6.0', 1),
(4, '4.7.0', 1),
(5, '1.19.1', 2),
(6, '1.21.1', 2),
(7, '1.23.0', 2),
(8, '1.24.0', 2),
(9, '1.28.0', 2),
(10, '1.9.0', 3),
(11, '2.0.5', 3),
(12, '2.0.9', 3),
(13, '2.2', 3),
(14, '3.3', 4),
(15, '3.9', 4),
(16, '4.0', 4),
(17, '4.2.3', 4),
(18, '4.6', 4),
(19, '4.7', 4),
(20, '4.7.1', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
CREATE TABLE `tests` (
  `id` int(11) NOT NULL,
  `test_name` varchar(100) DEFAULT 'unnamed',
  `test_group` varchar(250) NOT NULL DEFAULT 'default',
  `test_date` datetime DEFAULT NULL,
  `fk_software_id` int(11) DEFAULT '0',
  `fk_software_version_id` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tests`
--


-- --------------------------------------------------------

--
-- Table structure for table `vulnerabilities`
--

DROP TABLE IF EXISTS `vulnerabilities`;
CREATE TABLE `vulnerabilities` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `cve` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `fk_software_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vulnerabilities`
--

INSERT INTO `vulnerabilities` (`id`, `name`, `cve`, `description`, `fk_software_id`) VALUES
(1, 'vulnerability in pmd_pdf.php', 'CVE-2013-5003', 'SQL injection vulnerabilities, producing a privilege escalation (control user).', 1);


-- --------------------------------------------------------

--
-- Table structure for table `vulnerability_software`
--

DROP TABLE IF EXISTS `vulnerability_software`;
CREATE TABLE `vulnerability_software` (
  `id` int(11) NOT NULL,
  `fk_version_id` int(11) NOT NULL,
  `fk_vulnerability_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vulnerability_software`
--

INSERT INTO `vulnerability_software` (`id`, `fk_version_id`, `fk_vulnerability_id`) VALUES
(1, 1, 1);


-- --------------------------------------------------------

--
-- Table structure for table `vulnerable_files`
--

DROP TABLE IF EXISTS `vulnerable_files`;
CREATE TABLE `vulnerable_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(250) NOT NULL,
  `fk_vulnerability_software` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vulnerable_files`
--

INSERT INTO `vulnerable_files` (`id`, `file_name`, `fk_vulnerability_software`) VALUES
(1, 'pmd_pdf.php', 1);


-- --------------------------------------------------------

--
-- Table structure for table `vulnerable_functions`
--

DROP TABLE IF EXISTS `vulnerable_functions`;
CREATE TABLE `vulnerable_functions` (
  `id` int(11) NOT NULL,
  `function_name` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `line_number` int(11) NOT NULL,
  `fk_vulnerable_file` int(11) NOT NULL,
  `fk_vulnerability_software` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `vulnerable_functions`
--


-- --------------------------------------------------------

--
-- Table structure for table `vulnerable_lines`
--

DROP TABLE IF EXISTS `vulnerable_lines`;
CREATE TABLE `vulnerable_lines` (
  `id` int(11) NOT NULL,
  `line_number` int(11) NOT NULL,
  `fk_vulnerability_software` int(11) NOT NULL,
  `fk_vulnerable_file` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vulnerable_lines`
--

INSERT INTO `vulnerable_lines` (`id`, `line_number`, `fk_vulnerability_software`, `fk_vulnerable_file`) VALUES
(1, 74, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `covered_files`
--
ALTER TABLE `covered_files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `file_name` (`file_name`,`fk_test_id`);

--
-- Indexes for table `covered_lines`
--
ALTER TABLE `covered_lines`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `line_number` (`line_number`,`fk_file_id`);

--
-- Indexes for table `included_files`
--
ALTER TABLE `included_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `software`
--
ALTER TABLE `software`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `software_files`
--
ALTER TABLE `software_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `file_name` (`file_name`),
  ADD KEY `fk_software_files_description` (`fk_software_files_description`);

--
-- Indexes for table `software_files_description`
--
ALTER TABLE `software_files_description`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_software_id` (`fk_software_id`),
  ADD KEY `fk_software_version_id` (`fk_software_version_id`);

--
-- Indexes for table `software_functions`
--
ALTER TABLE `software_functions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `software_version`
--
ALTER TABLE `software_version`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_software_id` (`fk_software_id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `test_group` (`test_group`);

--
-- Indexes for table `vulnerabilities`
--
ALTER TABLE `vulnerabilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_software_id` (`fk_software_id`);

--
-- Indexes for table `vulnerability_software`
--
ALTER TABLE `vulnerability_software`
  ADD PRIMARY KEY (`id`,`fk_vulnerability_id`,`fk_version_id`);

--
-- Indexes for table `vulnerable_files`
--
ALTER TABLE `vulnerable_files`
  ADD PRIMARY KEY (`id`,`file_name`,`fk_vulnerability_software`);

--
-- Indexes for table `vulnerable_functions`
--
ALTER TABLE `vulnerable_functions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_vulnerable_file` (`fk_vulnerable_file`),
  ADD KEY `fk_vulnerability_software` (`fk_vulnerability_software`);

--
-- Indexes for table `vulnerable_lines`
--
ALTER TABLE `vulnerable_lines`
  ADD PRIMARY KEY (`id`,`line_number`,`fk_vulnerable_file`,`fk_vulnerability_software`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `covered_files`
--
ALTER TABLE `covered_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10655;

--
-- AUTO_INCREMENT for table `covered_lines`
--
ALTER TABLE `covered_lines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=836261;

--
-- AUTO_INCREMENT for table `included_files`
--
ALTER TABLE `included_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `software`
--
ALTER TABLE `software`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `software_files`
--
ALTER TABLE `software_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9236;

--
-- AUTO_INCREMENT for table `software_files_description`
--
ALTER TABLE `software_files_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `software_functions`
--
ALTER TABLE `software_functions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70059;

--
-- AUTO_INCREMENT for table `software_version`
--
ALTER TABLE `software_version`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `vulnerabilities`
--
ALTER TABLE `vulnerabilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `vulnerability_software`
--
ALTER TABLE `vulnerability_software`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `vulnerable_files`
--
ALTER TABLE `vulnerable_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `vulnerable_functions`
--
ALTER TABLE `vulnerable_functions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `vulnerable_lines`
--
ALTER TABLE `vulnerable_lines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=466;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
